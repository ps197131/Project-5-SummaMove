import 'package:flutter/material.dart';
import 'package:summa_move_flutter_app/tabs/studenten.dart';
import 'package:summa_move_flutter_app/tabs/beheerders.dart';
import './stack.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
          drawer: const Drawer(),
          appBar: AppBar(
            title: const Text("Home"),
            bottom: const TabBar(
              tabs: [
                Tab(icon: Icon(Icons.add_moderator)),
                Tab(icon: Icon(Icons.card_membership)),
              ],
            ),
          ),
          body: const TabBarView(
            children: <Widget>[
              Beheerder(),
              Studenten(),
            ],
          )),
    );
  }
}