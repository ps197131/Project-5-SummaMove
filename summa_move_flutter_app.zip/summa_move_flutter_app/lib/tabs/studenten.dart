import 'package:flutter/material.dart';

class Studenten extends StatelessWidget {
  const Studenten({super.key});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          const Text("Studenten"),
          Padding(
            padding: const EdgeInsets.only(top: 16.0),
            child: ElevatedButton(
              onPressed: () {
                Navigator.of(context).pushNamed("/oefeningen");
              },
              child: const Text('Oefeningen'),
            ),
          ),
        ],
      ),
    );
  }
}