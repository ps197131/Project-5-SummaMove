import 'package:flutter/material.dart';

class Beheerder extends StatelessWidget {
  const Beheerder({super.key});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: const <Widget>[
          Text("Beheerders"),
        ],
      ),
    );
  }
}