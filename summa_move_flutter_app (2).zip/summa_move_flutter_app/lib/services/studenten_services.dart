import 'dart:convert';
import 'package:summa_move_flutter_app/models/beheerders.dart';
import 'package:summa_move_flutter_app/models/studenten.dart';
import 'package:http/http.dart' as http;

class StudentenServire {
  Future<List<Student>> getAll() async {
    List<Student> studenten = [];
    final response =
    await http.get(Uri.parse('https://127.0.0.1:8000/api'));
    if (response.statusCode != 200) {
      throw Exception(
          'Fout bij het ophalen van alle studenten (${response.statusCode}).');
    }
    // final List<dynamic> data = jsonDecode(response.body);
    // for (int i = 0; i < data.length; i++) {
    //   final studenten = Studenten(
    //       id: data[i]['id'],
    //       name: data[i]['name'],
    //       klas: data[i]['klas'],
    //       studenten: []);

    //   final List<dynamic> studenten = data[i]['studenten'];
    //   for (int j = 0; j < studenten.length; j++) {
    //     final student = Student(
    //         id: studenten[j]['id'], name: studenten[j]['name'], studenten: []);
    //     student.studenten!.add(student);
    //   }
    //   studenten.add(student);
    // }
    // return studenten;
  // }
  // Future<Student> post(Student student async {
  // final response =
  // await http.post(Uri.parse('https://127.0.0.1:8000'),
  // headers: <String, String>{
  // 'Content-Type': 'application/json',
  // },
  // body: jsonEncode ({
  // 'name': student.name,
  // 'klas': student.klas,
  // }));
  //
  // if (response.statusCode != 201) {
  // throw Exception('Het is niet gelukt om de Student toe te voegen');
  // }

  // final result = jsonDecode(response.body);
  // return Student(
  // id: result['id'], name: result['name'], klas: result['klas']);
  // }
  // Future<Student> put (int id, Student student) async {
  // final response =
  // await http.put(Uri.parse('https://127.0.0.1:8000/api'),
  // headers: <String, String>{
  // 'Content-Type': 'application/json',
  // },
  // body: jsonEncode({
  // 'id': student.id,
  // 'name': student.name,
  // 'klas': student.klas,
  // }));

  // if (response.statusCode != 200) {
  // throw Exception('Het is niet gelukt om de Studenten toe te voegen');
  // }
  // final result = jsonDecode(response.body);
  // return Studenten(
  // id: result['id'], name: result['name'], klas: result['klas']);
  // }

  // Future<bool> delete(int studentID) async {
  // final response = await http.delete(
  // Uri.parse('https://127.0.0.1:8000/api'));
  // return response.statusCode == 200;

  }

  // Future<bool> addStudentToStudent(int studentID, int studentID) async {
  // final response =
  // await http.post(Uri.parse('https://127.0.0.1:8000/api'));
  // return response.statusCode == 200;
  // }

  // Future<bool> deleteStudentFromStudent(int StudentID, int studentID) async {
  // final response =
  // await http.delete(Uri.parse('https://127.0.0.1:8000/api'));
  // return response.statusCode == 200;

  }
}