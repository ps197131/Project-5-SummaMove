import 'dart:convert';
import 'package:summa_move_flutter_app/models/beheerders.dart';
import 'package:summa_move_flutter_app/models/studenten.dart';
import 'package:http/http.dart' as http;

class BeheerdersService {
  Future<List<Beheerder>> getAll() async {
  List<Beheerder> beheerders = [];
  final response =
  await http.get(Uri.parse('https://127.0.0.1:8000/api'));
  if (response.statusCode != 200) {
  throw Exception(
    'Fout bij het ophalen van alle beheerders (${response.statusCode}).');
  }
  final List<dynamic> data = jsonDecode(response.body);
  for (int i = 0; i < data.length; i++) {
    final beheerder = Beheerder(
      id: data[i]['id'],
      name: data[i]['name'],
      klas: data[i]['klas'],
      student: []);

    final List<dynamic> studenten = data[i]['studenten'];
    for (int j = 0; j < studenten.length; j++) {
      final student = Student(
        id: studenten[j]['id'], name: studenten[j]['name'], beheerders: []);
      beheerder.student!.add(student);
    }
    beheerders.add(beheerder);
  }
  return beheerders;
  }
  Future<Beheerder> post(Beheerder beheerder) async {
    final response =
  await http.post(Uri.parse('https://127.0.0.1:8000'),
  headers: <String, String>{
    'Content-Type': 'application/json',
  },
  body: jsonEncode ({
    'name': beheerder.name,
    'klas': beheerder.klas,
  }));

    if (response.statusCode != 201) {
       throw Exception('Het is niet gelukt om de Beheerder toe te voegen');
    }

    final result = jsonDecode(response.body);
    return Beheerder(
    id: result['id'], name: result['name'], klas: result['klas']);
  }
  Future<Beheerder> put (int id, Beheerder beheerder) async {
    final response =
  await http.put(Uri.parse('https://127.0.0.1:8000/api'),
  headers: <String, String>{
    'Content-Type': 'application/json',
  },
  body: jsonEncode({
    'id': beheerder.id,
    'name': beheerder.name,
    'klas': beheerder.klas,
  }));

    if (response.statusCode != 200) {
  throw Exception('Het is niet gelukt om de Beheerder toe te voegen');
  }
    final result = jsonDecode(response.body);
    return Beheerder(
    id: result['id'], name: result['name'], klas: result['klas']);
  }

  Future<bool> delete(int beheerderID) async {
    final response = await http.delete(
    Uri.parse('https://127.0.0.1:8000/api'));
    return response.statusCode == 200;

  }

  Future<bool> addStudentToBeheerder(int beheerderID, int studentID) async {
    final response =
    await http.post(Uri.parse('https://127.0.0.1:8000/api'));
    return response.statusCode == 200;
  }

  Future<bool> deleteStudentFromBeheerder(int beheerderID, int studentID) async {
    final response =
    await http.delete(Uri.parse('https://127.0.0.1:8000/api'));
    return response.statusCode == 200;

  }
}