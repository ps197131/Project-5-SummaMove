import 'beheerders.dart';


class Student {
  final int id;
  final String name;
  final List<Beheerder>? beheerders;

  Student({
    required this.id,
    required this.name,
    this.beheerders,
  })
}
  // @override bool operator==(Object o) {
  //   if (o is Student) {
  //     return o.id == this.id;
  //   }
  //   else {
  //     return false;
  //   }
  // }

