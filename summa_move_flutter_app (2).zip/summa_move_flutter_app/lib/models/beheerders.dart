import 'package:summa_move_flutter_app/models/studenten.dart';

class Beheerder {
  final int id;
  final String name;
  final String klas;
  final List<Student>? student;

  Beheerder({
    required this.id,
    required this.name,
    required this.klas,
    this.student,
  });
}