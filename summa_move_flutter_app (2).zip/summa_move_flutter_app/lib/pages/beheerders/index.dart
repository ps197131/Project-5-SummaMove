import 'package:flutter/material.dart';
import '../../models/beheerders.dart';

class BeheerdersIndex extends StatelessWidget {
  const BeheerdersIndex({Key? key}) : super(key:  key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Beheerders'),),
      body: FutureBuilder<List<Beheerder>>(
        future: beheerder_services.dart,
      ),
    )
  }
}