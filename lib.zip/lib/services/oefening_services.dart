import 'dart:convert';
import 'package:summa_move_flutter_app/models/oefeningen.dart';
import 'package:http/http.dart' as http;

class OefeningService {
  List<Oefening> oefeningen = [];
  Future<List<Oefening>> getAll() async {
    final response =
        await http.get(Uri.parse('http://127.0.0.1:8000/api/oefeningen'));
    if (response.statusCode != 200) {
      throw Exception(
          'Fout bij het ophalen van alle oefeningen (${response.statusCode}).');
    }
    final Map<String, dynamic> data = Map.castFrom(json.decode(response.body));
    for (int i = 0; i < data['data'].length; i++) {
      final oefening = Oefening(
          id: data['data'][i]['id'],
          naam_EN: data['data'][i]['naam_EN'],
          naam_NL: data['data'][i]['naam_NL'],
          omschrijving_NL: data['data'][i]['omschrijving_NL'],
          omschrijving_EN: data['data'][i]['omschrijving_EN'],
          prestaties: []);

      oefeningen.add(oefening);
    }
    return oefeningen;
  }

  // Future<Oefening> GetByID(int oefeningID) async{
  //   final id = oefeningID;
  //   final url = 'https://127.0.0.1:8000/api/oefeningen/$oefeningen_id';
  //   final response = await http.get(
  //     Uri.parse(url),
  //     headers: {
  //       'Content-Type': 'application/json',
  //
  //     },
  //   );
 //}

  Future<Oefening> post(Oefening oefening) async {
    final response =
        await http.post(Uri.parse('http://127.0.0.1:8000/api/oefeningen'),
            headers: <String, String>{
              'Content-Type': 'application/json',
            },
            body: jsonEncode({
              'naam_NL': oefening.naam_NL,
              'naam_EN': oefening.naam_EN,
              'omschrijving_NL': oefening.omschrijving_NL,
              'omschrijving_EN': oefening.omschrijving_EN,
            }));

    if (response.statusCode != 201) {
      throw Exception('Het is niet gelukt om de oefening toe te voegen');
    }

    final result = jsonDecode(response.body);
    return Oefening(
        id: result['id'],
        naam_EN: result['naam_EN'],
        naam_NL: result['naam_NL'],
        omschrijving_NL: result['omschrijving_NL'],
        omschrijving_EN: result['omschrijving_EN'],
        prestaties: []);
  }

  Future<Oefening> put(int id, Oefening oefening) async {
    final response = await http.put(Uri.parse('http://127.0.0.1:8000/api/oefeningen/$id'),
        headers: <String, String>{
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'naam_NL': oefening.naam_NL,
          'naam_EN': oefening.naam_EN,
          'omschrijving_NL': oefening.omschrijving_NL,
          'omschrijving_EN': oefening.omschrijving_EN,
        }));

    if (response.statusCode != 200) {
      throw Exception('Het is niet gelukt om de Beheerder toe te voegen');
    }
    final result = jsonDecode(response.body);
    return Oefening(
        id: result['id'],
        naam_EN: result['naam_EN'],
        naam_NL: result['naam_NL'],
        omschrijving_NL: result['omschrijving_NL'],
        omschrijving_EN: result['omschrijving_EN'],
        prestaties: []);
  }

  Future<bool> delete(int id,) async {
    print('Delete 1 $id');
    final response = await http.delete(Uri.parse('http://127.0.0.1:8000/api/oefeningen/$id'));
    print('Delete 2 ${response.statusCode}');
    return response.statusCode == 202;
  }

  Future<bool> addPrestatieToOefening(
      int oefeningen_id, int prestaties_id) async {
    final response = await http.post(Uri.parse(
        'https://127.0.0.1:8000/api/oefeningen/${oefeningen_id}/prestaties/${prestaties_id}'));
    return response.statusCode == 200;
  }

  Future<bool> deletePrestatieFromOefening(
      int oefeningen_id, int prestaties_id) async {
    final response = await http.delete(Uri.parse(
        'https://127.0.0.1:8000/api/oefeningen/${oefeningen_id}/prestaties/${prestaties_id}'));
    return response.statusCode == 200;
  }
}
