import 'dart:convert';
import 'package:summa_move_flutter_app/models/oefeningen.dart';
import 'package:summa_move_flutter_app/models/prestaties.dart';
import 'package:http/http.dart' as http;

class PrestatieService {
  Future<List<Prestatie>> getAll() async {
    List<Prestatie> prestaties = [];
    final response =
    await http.get(Uri.parse('https://127.0.0.1:8000/api/prestaties'));
    if (response.statusCode != 200) {
      throw Exception(
          'Fout bij het ophalen van alle prestaties (${response.statusCode}).');
    }
    final Map<String, dynamic> responsedata = jsonDecode(response.body);
    final List<dynamic> data = responsedata['data'];
    for (int i = 0; i < data.length; i++) {
      final prestatie = Prestatie(
          id: data[i]['id'],
          aantal: data[i]['aantal'],
          van: data[i]['van'],
          tot: data[i]['tot'],
          datum: data[i]['datum'],
          oefeningen_id: data[i]['oefeningen_id'],
          user_id: data[i]['user_id'],
          oefening: []);
      prestaties.add(prestatie);
    }
    return prestaties;
  }
  // Future<Student> post(Student student async {
  // final response =
  // await http.post(Uri.parse('https://127.0.0.1:8000'),
  // headers: <String, String>{
  // 'Content-Type': 'application/json',
  // },
  // body: jsonEncode ({
  // 'name': student.name,
  // 'klas': student.klas,
  // }));
  //
  // if (response.statusCode != 201) {
  // throw Exception('Het is niet gelukt om de Student toe te voegen');
  // }
  //
  // final result = jsonDecode(response.body);
  // return Student(
  // id: result['id'], name: result['name'], klas: result['klas']);
  // }
  // Future<Student> put (int id, Student student) async {
  // final response =
  // await http.put(Uri.parse('https://127.0.0.1:8000/api'),
  // headers: <String, String>{
  // 'Content-Type': 'application/json',
  // },
  // body: jsonEncode({
  // 'id': student.id,
  // 'name': student.name,
  // 'klas': student.klas,
  // }));
  //
  // if (response.statusCode != 200) {
  // throw Exception('Het is niet gelukt om de Studenten toe te voegen');
  // }
  // final result = jsonDecode(response.body);
  // return Studenten(
  // id: result['id'], name: result['name'], klas: result['klas']);
  // }
  //
  // Future<bool> delete(int studentID) async {
  // final response = await http.delete(
  // Uri.parse('https://127.0.0.1:8000/api'));
  // return response.statusCode == 200;
  //
  // }
  //
  // Future<bool> addStudentToStudent(int studentID, int studentID) async {
  // final response =
  // await http.post(Uri.parse('https://127.0.0.1:8000/api'));
  // return response.statusCode == 200;
  // }
  //
  // Future<bool> deleteStudentFromStudent(int StudentID, int studentID) async {
  // final response =
  // await http.delete(Uri.parse('https://127.0.0.1:8000/api'));
  // return response.statusCode == 200;

  }