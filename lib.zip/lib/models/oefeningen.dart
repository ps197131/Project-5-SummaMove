import 'package:summa_move_flutter_app/models/prestaties.dart';

class Oefening {
  final int id;
  final String naam_EN;
  final String naam_NL;
  final String omschrijving_EN;
  final String omschrijving_NL;
  final List<Prestatie>? prestaties;

  Oefening({
    required this.id,
    required this.naam_EN,
    required this.naam_NL,
    required this.omschrijving_EN,
    required this.omschrijving_NL,
    this.prestaties,
  });
}