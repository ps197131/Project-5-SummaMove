import 'oefeningen.dart';


class Prestatie {
  final int id;
  final int aantal;
  final DateTime van;
  final DateTime tot;
  final DateTime datum;
  final int user_id;
  final int oefeningen_id;
  final List<Oefening>? oefening;


  Prestatie({
    required this.id,
    required this.aantal,
    required this.van,
    required this.tot,
    required this.datum,
    required this.user_id,
    required this.oefeningen_id,
    this.oefening,
  });
}


