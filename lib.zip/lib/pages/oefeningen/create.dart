import 'package:summa_move_flutter_app/models/oefeningen.dart';
import 'package:summa_move_flutter_app/services/oefening_services.dart';
import 'package:flutter/material.dart';

class OefeningenCreate extends StatefulWidget {
  const OefeningenCreate({Key? key}) : super(key: key);

  @override
  State<OefeningenCreate> createState() => _OefeningenCreateState();
}

class _OefeningenCreateState extends State<OefeningenCreate> {
  final _formKey = GlobalKey<FormState>();
  final _naamNLController = TextEditingController();
  final _omschrijvingNLController = TextEditingController();
  final _naamENController = TextEditingController();
  final _omschrijvingENController = TextEditingController();

  @override
  void dispose() {
    _naamNLController.dispose();
    _naamENController.dispose();
    _omschrijvingENController.dispose();
    _omschrijvingNLController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(title: Text('Oefening - Create')),
        body: Form(
            key: _formKey,
            child: Column(
              children: [
                // Naam Engels
                TextFormField(
                  controller: _naamNLController,
                  textInputAction: TextInputAction.next,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: 'Naam(NL)',
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Vul naam in';
                    }
                    return null;
                  },
                ),
                //Naam Nederlands
                TextFormField(
                  controller: _naamENController,
                    textInputAction: TextInputAction.next,
                  decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: 'Naam(NL)',
                ),
                validator:(value){
                    if (value == null || value.isEmpty) {
                      return 'Vul naam in';
                    }
                    return null;
                },
                ),

                // Klas
                TextFormField(
                  controller: _omschrijvingNLController,
                  textInputAction: TextInputAction.next,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: 'Omschrijving',
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Vul omschrijving in';
                    }
                    return null;
                  },
                ),

                TextFormField(
                  controller: _omschrijvingENController,
                  textInputAction: TextInputAction.next,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: 'Omschrijving',
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'vul omschrijving in';
                    }
                    return null;
                  },
                ),



                // Save / Cancel
                Row(
                  children: [
                    ElevatedButton(
                      onPressed: () async {
                        if (_formKey.currentState!.validate() == false) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('Verbeter de fouten')),
                          );
                        }
                        ;
                        var oefening = Oefening(
                            id: 0,
                            naam_NL: _naamNLController.text,
                            naam_EN: _naamENController.text,
                            omschrijving_NL: _omschrijvingNLController.text,
                            omschrijving_EN: _omschrijvingENController.text);
                        oefening = await OefeningService().post(oefening);
                        Navigator.pop(context);
                      },
                      child: Text('Bewaren'),
                    ),
                    ElevatedButton(
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                      child: Text('Annuleren'),
                    ),
                  ],
                )
              ],
            )));
  }
}
