import 'package:summa_move_flutter_app/models/oefeningen.dart';
import 'package:summa_move_flutter_app/services/oefening_services.dart';
import 'package:flutter/material.dart';

class OefeningenEdit extends StatefulWidget {
  const OefeningenEdit({Key? key, required this.oefening}) : super(key: key);
  final Oefening oefening;

  @override
  State<OefeningenEdit> createState() => _OefeningenEditState();
}

class _OefeningenEditState extends State<OefeningenEdit> {
  final _formKey = GlobalKey<FormState>();
  final _naamNLController = TextEditingController();
  final _naamENController = TextEditingController();
  final _omschrijvingNLController = TextEditingController();
  final _omschrijvingENController = TextEditingController();

  @override
  void initState() {
    _naamNLController.text = widget.oefening.naam_NL;
    _naamENController.text = widget.oefening.naam_EN;
    _omschrijvingNLController.text = widget.oefening.omschrijving_NL;
    _omschrijvingENController.text = widget.oefening.omschrijving_EN;
    super.initState();
  }

  @override
  void dispose() {
    _naamNLController.dispose();
    _naamENController.dispose();
    _omschrijvingENController.dispose();
    _omschrijvingNLController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(title: Text('Champions - Edit')),
        body: Form(
            key: _formKey,
            child: Column(
              children: [
                // NaamNL
                TextFormField(
                  controller: _naamNLController,
                  textInputAction: TextInputAction.next,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: 'Naam',
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Vul naam in';
                    }
                    return null;
                  },
                ),

                TextFormField(
                  controller: _naamENController,
                  textInputAction: TextInputAction.next,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: 'Naam',
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Vul naam in';
                    }
                    return null;
                  },
                ),

                // Klas
                TextFormField(
                  controller: _omschrijvingENController,
                  textInputAction: TextInputAction.next,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: 'Omschrijving',
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Vul omschrijving in';
                    }
                    return null;
                  },
                ),

                TextFormField(
                  controller: _omschrijvingNLController,
                  textInputAction: TextInputAction.next,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: 'Omschrijving',
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Vul omschrijving in';
                    }
                    return null;
                  },
                ),

                // Save / Cancel
                Row(
                  children: [
                    ElevatedButton(
                      onPressed: () async {
                        if (_formKey.currentState!.validate() == false) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('Verbeter de fouten')),
                          );
                        }
                        ;
                        var oefening = Oefening(
                            id: widget.oefening.id,
                            naam_EN: _naamENController.text,
                            naam_NL: _naamNLController.text,
                            omschrijving_NL: _omschrijvingNLController.text,
                            omschrijving_EN: _omschrijvingENController.text);
                        oefening = await OefeningService()
                            .put(widget.oefening.id, oefening);
                        Navigator.pop(context);
                      },
                      child: Text('Bewaren'),
                    ),
                    ElevatedButton(
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                      child: Text('Annuleren'),
                    ),
                  ],
                )
              ],
            )));
  }
}
