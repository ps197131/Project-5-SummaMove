import 'package:summa_move_flutter_app/models/prestaties.dart';
import 'package:summa_move_flutter_app/models/oefeningen.dart';
import 'package:summa_move_flutter_app/services/oefening_services.dart';
import 'package:summa_move_flutter_app/services/prestaties_services.dart';
import 'package:flutter/material.dart';

class OefeningenPrestaties extends StatefulWidget {
  OefeningenPrestaties({Key? key, required this.oefening}) : super(key: key);
  final Oefening oefening;

  @override
  State<OefeningenPrestaties> createState() => _OefeningenPrestatiesState();
}

class _OefeningenPrestatiesState extends State<OefeningenPrestaties> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Oefening Prestaties')),
      body: Column(
        children: [

          // Oefening Data
          Text(
              '${widget.oefening.naam_NL} (${widget.oefening.omschrijving_NL})'),

          // Hobbies
          Expanded(
            child: FutureBuilder<List<Prestatie>>(
              future: PrestatieService().getAll(),
              builder: (context, snapshot) {
                if (snapshot.hasError) {
                  return Text(snapshot.error.toString());
                }
                if (snapshot.hasData == false) {
                  return CircularProgressIndicator();
                }
                return ListView.builder(
                  itemCount: snapshot.data!.length,
                  itemBuilder: (context, index) {
                    return Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(snapshot.data![index].user_id as String),
                        Checkbox(
                          value: widget.oefening.prestaties!
                              .contains(snapshot.data![index]),
                          onChanged: (value) {
                            if (value == true) {
                              // 'Toevoegen van prestatie;
                              OefeningService().addPrestatieToOefening(
                                  widget.oefening.id, snapshot.data![index].id);
                              widget.oefening.prestaties!
                                  .add(snapshot.data![index]);
                            } else {
                              OefeningService().deletePrestatieFromOefening(
                                  widget.oefening.id, snapshot.data![index].id);
                              Prestatie prestatie = widget.oefening.prestaties!
                                  .firstWhere((element) =>
                                      element.id == snapshot.data![index].id);
                              if (prestatie != null) {
                                widget.oefening.prestaties!.remove(prestatie);
                              }
                            }
                            setState(() {});
                          },
                        )
                      ],
                    );
                  },
                );
              },
            ),
          )
        ],
      ),
    );
  }
}
