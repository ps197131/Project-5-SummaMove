import 'package:flutter/material.dart';
import 'package:summa_move_flutter_app/pages/oefeningen/create.dart';
import '../../models/oefeningen.dart';
import '../../services/oefening_services.dart';
import 'edit.dart';
import 'oefeningen-prestaties.dart';

class OefeningenIndex extends StatefulWidget {
  const OefeningenIndex({Key? key}) : super(key: key);

  @override
  State<OefeningenIndex> createState() => _OefeningenIndexState();
}

class _OefeningenIndexState extends State<OefeningenIndex> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Oefeningen Index'),
      ),
      body: FutureBuilder<List<Oefening>>(
        future: OefeningService().getAll(),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Text(snapshot.error.toString());
          }
          if (!snapshot.hasData) {
            return const CircularProgressIndicator();
          }
          return _oefeningenIndex(snapshot.data!, context);
        },
      ),
      floatingActionButton: FloatingActionButton(
        child: const Icon(Icons.add),
        onPressed: () => _createOefening(context),
      ),
    );
  }

  Widget _oefeningenIndex(List<Oefening> list, BuildContext context) {
    return ListView.builder(
      itemCount: list.length,
      itemBuilder: (context, index) {
        return ListTile(
          leading: _oefeningprestaties(list[index], context),
          title: Row(
            children: [
              Expanded(child: Text(list[index].naam_NL)),
              _editOefening(list[index], context),
              _deleteOefening(list[index].id, context)
            ],
          ),
          subtitle:
              Text('Aantal Prestaties: ${list[index].prestaties?.length ?? 0}'),
        );
      },
    );
  }

  Future<void> _createOefening(BuildContext context) async {
    await Navigator.of(context).push(MaterialPageRoute(
      builder: (context) => const OefeningenCreate(),
    ));
    setState(() {});
  }

  Widget _editOefening(Oefening oefening, BuildContext context) {
    return GestureDetector(
      onTap: () async {
        await Navigator.of(context).push(MaterialPageRoute(
          builder: (context) => OefeningenEdit(oefening: oefening),
        ));
        setState(() {});
      },
      child: const Icon(Icons.edit),
    );
  }

  Widget _deleteOefening(int id, BuildContext context) {
    return GestureDetector(
      onTap: () async {
        bool gelukt = await OefeningService().delete(id);
        if (gelukt) {
// refresh scherm
          setState(() {});
        } else {
          if (context.mounted) {
            showDialog(
              context: context,
              builder: (context) {
                return AlertDialog(
                  title: const Text('Oefening - Delete'),
                  content: const Text('Verwijderen is mislukt'),
                  actions: [
                    TextButton(
                        onPressed: () => Navigator.of(context).pop(),
                        child: const Text('Ok'))
                  ],
                );
              },
            );
          }
        }
      },
      child: const Icon(Icons.delete_outline),
    );
  }

  _oefeningprestaties(Oefening oefening, BuildContext context) {
    return GestureDetector(
      onTap: () async {
        await Navigator.of(context).push(MaterialPageRoute(
          builder: (context) => OefeningenPrestaties(oefening: oefening),
        ));
        setState(() {});
      },
      child: const Icon(Icons.account_box_outlined),
    );
  }
}
